<div class="text-box">
      <div><img src="<?php bloginfo('template_directory'); ?>/images/ico-cp.jpg" align="left" style="margin:5px 20px 40px 20px;" />
            <p><a href="#"><strong>User-Friendly Control Panel</strong></a><br />
          Our web hosting control panel is fast and responsive, it is very easy to use yet it provides full control over your website(s) and domains. You are able to manage your hosting account with simple point &amp; click and drag &amp; drop actions.</p>
          </div>
    </div>
        <div style="height:5px;"></div>
        <div class="text-box">
      <div><img src="<?php bloginfo('template_directory'); ?>/images/ico-app-installer.jpg" align="left" style="margin:5px 20px 40px 20px;" />
            <p><a href="#"><strong>Web applications installer</strong></a><br />
          Our web hosting control panel is fast and responsive, it is very easy to use yet it provides full control over your website(s) and domains. You are able to manage your hosting account with simple point &amp; click and drag &amp; drop actions.</p>
          </div>
    </div>
        <div style="height:5px;"></div>
        <div class="text-box">
      <div><img src="<?php bloginfo('template_directory'); ?>/images/ico-free-designs.jpg" align="left" style="margin:5px 20px 40px 20px;" />
            <p><a href="#"><strong>Free web site designs</strong></a><br />
          Our web hosting control panel is fast and responsive, it is very easy to use yet it provides full control over your website(s) and domains. You are able to manage your hosting account with simple point &amp; click and drag &amp; drop actions.</p>
          </div>
    </div>
        <div style="height:5px;"></div>
        <div class="text-box">
      <div><img src="<?php bloginfo('template_directory'); ?>/images/ico-support.jpg" align="left" style="margin:5px 20px 40px 20px;" />
            <p><a href="#"><strong>Free web site designs</strong></a><br />
          Our web hosting control panel is fast and responsive, it is very easy to use yet it provides full control over your website(s) and domains. You are able to manage your hosting account with simple point &amp; click and drag &amp; drop actions.</p>
          </div>
    </div>