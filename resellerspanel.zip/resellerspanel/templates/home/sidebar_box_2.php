       <div class="text-box home-4 <?php echo $class;?>">
          <div>
            <h3><?php echo $title;?> @ <?php echo $price_from;?> /mo</h3>
            <span><?php echo $content;?> <a href="<?php echo $page_url;?>">Read More</a></span> </div>
        </div>