      <div class="sidebar-box <?php echo $class;?>">
		<div class="sidebar-box-header"><h4><?php echo $title;?> @ <?php echo $price_from;?> <span class="sidebar-box-header-period">/mo</span></h4></div>
		<div class="sidebar-box-content"><p><?php echo $content;?></p> 
		  <a href="<?php echo $page_url;?>"><?php echo $more;?></a></div>
	   </div><br />