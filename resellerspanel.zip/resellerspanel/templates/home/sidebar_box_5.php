					<div id="<?php echo $class;?>">
						<div class="service_header"><span><a href="<?php echo $page_url;?>"><?php echo $title;?></a></span>  @ <?php echo $price_from;?>/mo<div class="right"><a href="<?php echo $rp_signup_url?>">ORDER<br />NOW</a></div></div>
						<?php echo $content;?>
					</div>