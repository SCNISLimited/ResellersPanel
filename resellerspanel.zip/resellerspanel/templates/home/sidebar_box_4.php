        <div id="other-services-text">
            <div class="service_header"><span><a href="<?php echo $page_url;?>"><?php echo $title;?></a></span>  - from <?php echo $price_from;?>/mo<div class="right"><a href="<?php echo $rp_signup_url?>">order now</a></div></div>
            <?php echo $content;?>
        </div>