        <div id="shared-box1" class="<?php echo $class;?>">
            <div id="box-title"><h4><a href="<?php echo $page_url;?>"><?php echo $title;?></a></h4></div>
            <div id="box-price"><span class="box-price-currency">@ </span><span class="box-price-value"><?php echo $price_from;?></span> &nbsp;<span class="box-price-period"> a month</span>
            </div>
            <div id="box-content1">
                <?php echo $content;?>
            </div>
            <form method="get" class="pr_rp_sing_up_form" action="<?php echo $page_url;?>">
                <button class="rpwp-button colorize"><span class="gloss"></span>Learn More</button>        
            </form>
        </div>