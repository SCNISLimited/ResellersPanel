<div id="domain-search-area-4">
	<div id="domain-search-form"><h3>Check your Domain Availability...</h3>
    <div>[domain_search tld="<?php echo $tld?>"]</div></div>
    <div id="promo-tlds">
    <h3>Free Domain Manager</h3>
    <p><a href="[rp_store_info key='demo']?auto_login=true" target="_blank"><strong>Live Demo</strong></a> - lock option, edit Whois, edit name servers, custom DNS records, URL redirection, etc.</p>
    </div>
</div>