    <div id="domain-banner-1">
      <h3 class="domain-banner-title-1">Get Your Unique Domain Name</h3>
      <div>[domain_search tld='<?php echo $tld?>']</div>
      <h4>Choose From Over <strong class="tld-cont"><?php echo $tld_count;?></strong> TLDs</h4>
    </div>