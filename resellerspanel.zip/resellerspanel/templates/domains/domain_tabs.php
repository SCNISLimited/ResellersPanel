<ul class="domain-tabs">
	<li><a href="#">Domain Name + Hosting</a></li>
	<li><a href="#">Domain Name Only</a></li>
	<li><a href="#">Domain TLD Details</a></li>
</ul>
<div class="domain-panes">
	<div><?php echo rp_tld_hosting_price(array('id_protect'=>$id_protect)) ?></div>
	<div><?php echo rp_tld_price(array('id_protect'=>$id_protect)) ?></div>
	<div><?php echo rp_tld_info(array('id_protect'=>$id_protect)) ?></div>
</div>
<script>
(function($){
    $("ul.domain-tabs").tabs("div.domain-panes > div");
})(jQuery);
</script>