<?php
$grouped_servers = array(
	'atom' => array('name' => 'Intel Atom Servers', 'servers' => array(), 'img' => 'intel.png'),
	'amd' => array('name' => 'AMD Opteron Servers', 'servers' => array(), 'img' => 'amd.png'),
	'xeon' => array('name' => 'Intel Xeon Servers', 'servers' => array(), 'img' => 'intel.png')
);
foreach ($rp_plans as $k => $v) {
	if (preg_match('/atom/i', $v['services']['processor'])) {
		$grouped_servers['atom']['servers'][] = $v;
	} else if (preg_match('/opteron/i', $v['services']['processor'])) {
		$grouped_servers['amd']['servers'][] = $v;
	} else if (preg_match('/xeon/i', $v['services']['processor'])) {
		$grouped_servers['xeon']['servers'][] = $v;
	}
}
?>
<?php
foreach ($grouped_servers as $key => $val) {
	if (empty($val['servers']))
		continue;
?>
<div class="dedicated-wrapper">
	<div class="dedicated-service-title">
		<div>
			<h2><?php echo $val['name']?></h2>
		</div>
		<div class="period-choice">
			<form>
				<div><label><input type="radio" class="dediperiod" data-grp="<?php echo $key?>" name="dedicated-period-<?php echo $key?>" value="1" checked><span class="radio-img"></span><span class="dedicated-period">Monthly</span></label></div>
				<div><label><input type="radio" class="dediperiod" data-grp="<?php echo $key?>" name="dedicated-period-<?php echo $key?>" value="3"><span class="radio-img"></span><span class="dedicated-period">Quarterly (10% OFF)</span></label></div>
				<div><label><input type="radio" class="dediperiod" data-grp="<?php echo $key?>" name="dedicated-period-<?php echo $key?>" value="6"><span class="radio-img"></span><span class="dedicated-period">Semi-annually (20% OFF)</span></label></div>
			</form>
		</div>
<?php /*
		<div>
			<span class="burst">%</span>
			<span class="promo-offer">20% OFF per month if you pre-pay for 6 months</span>
		</div>
 */ ?>
	</div>
<?php
	foreach ($val['servers'] as $k => $v) {
		$_format_cpu = _format_cpu($v['services']['processor']);
?>
	<div class="dedicated-plan">
		<table>
			<tbody>
				<tr>
					<td class="dedicated-plan-name"><img class="hide-for-small" src="<?php echo get_bloginfo('template_directory')?>/images/<?php echo $val['img']?>" alt="<?php echo $v['name']?>"><span><?php echo $v['name']?></span></td>
					<td class="dedicated-plan-features">
						<ul>
							<li>CPU: <strong><?php echo $_format_cpu['model']?></strong></li>
							<li><?php echo $v['services']['hdd_type']?>: <strong><?php echo "{$v['services']['hdd']}x " . __rp_value($v['services']['disk_space'], 'disk_space')?></strong></li>
							<li>Monthly Traffic: <strong><?php echo __rp_value($v['services']['traffic'], 'traffic')?></strong></li>
							<li><strong><?php echo "{$_format_cpu['cpu']} ({$_format_cpu['cores']} cores)"?></strong></li>
							<li>Upgradeable Storage: <strong><?php echo __rp_value($v['services']['upgradeable_storage'], 'upgradeable_storage')?></strong></li>
							<li>RAM: <strong><?php echo $v['services']['ram']?>GB</strong></li>
<?php
if (!empty($v['services']['assembly_time'])) { 
	$_t = $v['services']['assembly_time'];
	if ($_t % 7 == 0) {
		$_t = ($_t / 7);
		$_t = $_t > 1 ? "$_t Weeks" : "$_t Week";
	} else {
		$_t .= ' Days';
	}
?>
							<li><small>*<?php echo $_t; ?> Assembly Time</small></li>
<?php } ?>
						</ul>
					</td>
<?php
$data_atts = '';
foreach ($v['prices'] as $period => $price) {
	$_period = str_replace('period_', '', $period);
	$data_atts .= ' data-price-' . $_period . '="' . sprintf($v['currency_symbol'], $price[$v['store_currency']] / $_period) . '"';
}
?>
					<td class="dedicated-plan-price <?=$key?>" <?php echo $data_atts?>>
						<span class="price"><?php echo sprintf($v['currency_symbol'], $v['prices']['period_1'][$v['store_currency']])?></span>
						<span class="period">per month</span>
					</td>
					<td>
						<div data-id="<?php echo $v['rp_product_id'];?>" class="checkstock">Please wait...</div>
						<div data-id="<?php echo $v['rp_product_id'];?>" class="instock" style="display:none">
							<form method="get" class="pr_rp_sing_up_form" action="<?php echo $rp_signup_url?>">
								<button class="rpwp-button colorize"><span class="gloss"></span>Order</button>
								<?php if ($get_params_string):foreach ($get_params as $name=>$value):?>
								<input name="<?php echo $name?>" type="hidden" value="<?php echo $value?>" />
								<?php endforeach; endif;?>
								<input name="plan" type="hidden" value="<?php echo $v['rp_product_id'];?>" />
								<input name="period" type="hidden" value="1" class="period_<?=$key?>" />
							</form>
						</div>
						<div data-id="<?php echo $v['rp_product_id'];?>" class="outofstock" style="display:none">
							<span class="out-of-stock">Out of stock</span>
						</div>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
<?php } ?>
<?php if (!empty($show_link)) { ?>
	<div class="show-features">
		<a class="inline_compare" href="#compare_overlay">view additional server features</a>
	</div>
<?php } ?>
</div>
<?php } ?>
<script>
var checkforstock = true;
</script>
