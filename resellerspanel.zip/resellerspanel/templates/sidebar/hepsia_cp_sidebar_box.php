  <h3>Hepsia Control Panel</h3>
  <a href="<?php echo get_permalink(get_option('rp_hepsia_cp'));?>"><img src="<?php bloginfo( 'template_url' ); ?>/images/hepsia-control-panel-small.png" style="float:left; margin: 5px 10px 0px 0px; vertical-align:text-top;" /></a><?php echo $text;?>
  <br />
  <div class="line"></div>