  <h3>Web Accelerators</h3>
  <a href="<?php echo get_permalink(get_option('rp_web_accelerators'));?>"><img src="<?php bloginfo( 'template_url' ); ?>/images/hepsia-web-accelerators.jpg" /></a>
  <p><?php echo $text;?></p>
  <div class="line"></div>