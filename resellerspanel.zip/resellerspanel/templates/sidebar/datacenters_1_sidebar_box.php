  <h3>Data Centers</h3>
  <div class="sidebar-ad-usa-data-center"><a href="<?php echo rp_default_page_link(array('key'=>"datacenter_rp_data_centers_steadfast"));?>">Data Center in USA</a></div>
  <div class="sidebar-ad-uk-data-center"><a href="<?php echo rp_default_page_link(array('key'=>"datacenter_rp_data_centers_berkshire"));?>">Data Center in UK</a></div>
  <div class="sidebar-ad-au-data-center"><a href="<?php echo rp_default_page_link(array('key'=>"datacenter_rp_data_centers_sydney"));?>">Data Center in AU</a></div>
  <div class="sidebar-ad-fi-data-center"><a href="<?php echo rp_default_page_link(array('key'=>"datacenter_rp_data_centers_ficolo"));?>">Data Center in FI</a></div>
  <div class="sidebar-ad-bg-data-center"><a href="<?php echo rp_default_page_link(array('key'=>"datacenter_rp_data_centers_sofia"));?>">Data Center in BG</a></div>
  <div class="line"></div>