  <h3>Data Centers</h3>
  <a href="<?php echo get_permalink(get_option('rp_data_centers'));?>"><img src="<?php bloginfo( 'template_url' ); ?>/images/data-centers.png" /></a>
  <br />
  <div class="line"></div>