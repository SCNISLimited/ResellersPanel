  <h3>Advanced Domain Manager</h3>
  <a href="<?php echo get_permalink(get_option('rp_domain_manager'));?>"><img src="<?php bloginfo( 'template_url' ); ?>/images/hepsia-domain-manager.jpg" /></a>
  <p><?php echo $text;?></p>
  <div class="line"></div>