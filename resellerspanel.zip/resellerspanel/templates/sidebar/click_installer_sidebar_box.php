  <h3>1-click Installer</h3>
  <a href="<?php echo rp_default_page_link(array('key'=>"application_installer"));?>"><img src="<?php bloginfo( 'template_url' ); ?>/images/hepsia-1-click-installer.jpg" /></a>
  <p><?php echo $text;?></p>
  <div class="line"></div>