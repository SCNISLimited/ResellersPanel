  <h3>Customer Support</h3>
  <a href="<?php echo get_permalink(get_option('rp_customer_support'));?>"><img src="<?php bloginfo( 'template_url' ); ?>/images/customer-support.png" /></a>
  <br />
  <div class="line"></div>