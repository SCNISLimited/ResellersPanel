  <h3>Email Manager</h3>
  <a href="<?php echo get_permalink(get_option('rp_email_manager'));?>"><img src="<?php bloginfo( 'template_url' ); ?>/images/hepsia-email-manager.jpg" /></a>
  <p><?php echo $text;?></p>
  <div class="line"></div>